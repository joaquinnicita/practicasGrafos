from src.practica1 import *

def main():
    grafo = lee_entrada_1()
    lee_grafo_stdin(grafo)
    
if __name__ == '__main__':
    main()
